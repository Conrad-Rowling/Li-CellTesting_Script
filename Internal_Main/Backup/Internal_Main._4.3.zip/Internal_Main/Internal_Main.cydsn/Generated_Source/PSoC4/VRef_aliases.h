/*******************************************************************************
* File Name: VRef.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_VRef_ALIASES_H) /* Pins VRef_ALIASES_H */
#define CY_PINS_VRef_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define VRef_0			(VRef__0__PC)
#define VRef_0_PS		(VRef__0__PS)
#define VRef_0_PC		(VRef__0__PC)
#define VRef_0_DR		(VRef__0__DR)
#define VRef_0_SHIFT	(VRef__0__SHIFT)
#define VRef_0_INTR	((uint16)((uint16)0x0003u << (VRef__0__SHIFT*2u)))

#define VRef_INTR_ALL	 ((uint16)(VRef_0_INTR))


#endif /* End Pins VRef_ALIASES_H */


/* [] END OF FILE */
